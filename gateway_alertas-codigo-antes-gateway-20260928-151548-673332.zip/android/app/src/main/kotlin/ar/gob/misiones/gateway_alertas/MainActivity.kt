package ar.gob.misiones.gateway_alertas

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
